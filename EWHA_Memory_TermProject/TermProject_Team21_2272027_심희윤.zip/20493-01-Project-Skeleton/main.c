/*
 * main.c
 *
 * 20493-01 Computer Architecture
 * Term Project on Implementation of Cache Mechanism
 *
 * Skeleton Code Prepared by Prof. HyungJune Lee
 * Nov 17, 2024
 *
 */

/*
    name : Shim Heeyoon
    team : 21
    ID : 2272027
    department : Electronic and Electrical Engineering

*/

#include <stdio.h>
#include "cache_impl.h"
#include <conio.h>

int num_cache_hits = 0;
int num_cache_misses = 0;

int num_bytes = 0;
int num_access_cycles = 0;

int global_timestamp = 0;

int retrieve_data(void *addr, char data_type) { 
    //Get value by performing check_cache_hit() according to byte address and data type
    int value_returned = -1; /* accessed data */

    /* Invoke check_cache_data_hit() */
    value_returned = check_cache_data_hit(addr, data_type);
    
    num_access_cycles += CACHE_ACCESS_CYCLE;
    // Total cycle count increases by the cycle required for cache access (+1)

    /* In case of the cache miss event, access the main memory by invoking access_memory() */
    if (value_returned == -1) {
        num_cache_misses++; // If value_return value is -1, cache miss
        value_returned = access_memory(addr, data_type);
        // Extract values from main memory
        
        num_access_cycles += MEMORY_ACCESS_CYCLE;
        // Total cycle count increases by the cycle required for main memory access (+100)

    }

    global_timestamp++; 
    // Implemented LRU algorithm by increasing the timestamp by one

    return value_returned; 
}

int main(void) {
    FILE *ifp = NULL, *ofp = NULL;
    unsigned long int access_addr; /* byte address (located at 1st column) in "access_input.txt" */
    char access_type; /* 'b'(byte), 'h'(halfword), or 'w'(word) (located at 2nd column) in "access_input.txt" */
    int accessed_data; /* This is the data that you want to retrieve first from cache, and then from memory */ 
    
    init_memory_content();
    init_cache_content();
    
    ifp = fopen("access_input.txt", "r");
    if (ifp == NULL) {
        printf("Can't open input file\n");
        return -1;
    }
    ofp = fopen("access_output.txt", "w");
    if (ofp == NULL) {
        printf("Can't open output file\n");
        fclose(ifp);
        return -1;
    }

    fprintf(ofp, "[Accessed Data]\n");
    /* Fill out here by invoking retrieve_data() */
    while (fscanf(ifp, "%lu %c", &access_addr, &access_type) == 2) {
        // Byte address to access_addr and b / h / w value to access_type from file one line at a time

        accessed_data = retrieve_data(&access_addr, access_type);
        // Access the memory to get a value.

        if (accessed_data == -1) { // Handling exceptions (data does not exist in cache, the main memory)
            fprintf(ofp, "%lu %c is not in memory.\n", access_addr, access_type);
        }
        else { // If find data
            fprintf(ofp, "%lu %c %#x\n", access_addr, access_type, accessed_data);
            
            switch (access_type) { 
            case 'b':
                num_bytes += 1;
                break;
            case 'h':
                num_bytes += 2;
                break;
            case 'w':
                num_bytes += 4;
                break;
            }
            // Add the byte size of the accessed data to the num_bytes to calculate the bandwith value
        }
        
    }

    fprintf(ofp, "----------------------------------------------\n");
    if (DEFAULT_CACHE_ASSOC == 1) {
        fprintf(ofp, "[Direct mapped cache performance]\n");
    }
    else if (DEFAULT_CACHE_ASSOC == 2) {
        fprintf(ofp, "[2-way set associative cache performance]\n");
    }
    else if (DEFAULT_CACHE_ASSOC == 4) {
        fprintf(ofp, "[Fully associative cache performance]\n");
    }
    // Output formats for Direct mapped cache, 2-way set associative cache, and Fully associative cache

    int num_cache_access = num_cache_hits + num_cache_misses;
    // Total number of accesses is the number of hits in cache + the number of misses
    double hit_ratio = (double)num_cache_hits / (double)num_cache_access; 
    fprintf(ofp, "Hit ratio = %.2lf (%d/%d)\n", hit_ratio, num_cache_hits, num_cache_access);

    double bandwidth = (double)num_bytes / (double)num_access_cycles; 
    fprintf(ofp, "Bandwidth = %.2lf (%d/%d)\n", bandwidth, num_bytes, num_access_cycles);

    fclose(ifp);
    fclose(ofp);
    
    print_cache_entries();
    getch();

    // Call getch() so that the console window does not close immediately

    return 0;
}
