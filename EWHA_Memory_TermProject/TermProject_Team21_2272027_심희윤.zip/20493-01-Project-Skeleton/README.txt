README on how to use Makefile to compile source codes and create and run the executable (in Terminal)
(You don't need this information if you use Visual Studio.)

$ make clean
$ make 
$ ./cachetest


